public class Galaxy8 implements Celular {
    public void fazLigacao(){ System.out.println("Galaxy 8 realizando ligação."); }
    public void tiraFoto(){ System.out.println("Galaxy 8 tirando foto."); }
}