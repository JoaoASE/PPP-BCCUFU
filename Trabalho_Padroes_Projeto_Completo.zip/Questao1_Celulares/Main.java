public class Main {
    public static void main(String[] args) {
        FabricanteCelular samsung = Samsung.getInstance();
        FabricanteCelular apple = Apple.getInstance();

        Celular c1 = samsung.constroiCelular("Galaxy8");
        Celular c2 = apple.constroiCelular("IPhoneX");

        c1.fazLigacao();
        c1.tiraFoto();

        c2.fazLigacao();
        c2.tiraFoto();
    }
}