public class IPhoneS implements Celular {
    public void fazLigacao(){ System.out.println("iPhone S realizando ligação."); }
    public void tiraFoto(){ System.out.println("iPhone S tirando foto."); }
}