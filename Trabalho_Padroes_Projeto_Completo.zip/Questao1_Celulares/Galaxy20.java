public class Galaxy20 implements Celular {
    public void fazLigacao(){ System.out.println("Galaxy 20 realizando ligação."); }
    public void tiraFoto(){ System.out.println("Galaxy 20 tirando foto."); }
}