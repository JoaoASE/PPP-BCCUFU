public class Samsung implements FabricanteCelular {
    private static Samsung instancia;
    private Samsung(){}
    public static Samsung getInstance(){
        if(instancia == null) instancia = new Samsung();
        return instancia;
    }
    public Celular constroiCelular(String modelo){
        if(modelo.equalsIgnoreCase("Galaxy8")) return new Galaxy8();
        if(modelo.equalsIgnoreCase("Galaxy20")) return new Galaxy20();
        return null;
    }
}