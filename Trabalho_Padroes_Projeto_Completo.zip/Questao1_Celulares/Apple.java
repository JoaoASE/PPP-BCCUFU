public class Apple implements FabricanteCelular {
    private static Apple instancia;
    private Apple(){}
    public static Apple getInstance(){
        if(instancia == null) instancia = new Apple();
        return instancia;
    }
    public Celular constroiCelular(String modelo){
        if(modelo.equalsIgnoreCase("IPhoneX")) return new IPhoneX();
        if(modelo.equalsIgnoreCase("IPhoneS")) return new IPhoneS();
        return null;
    }
}