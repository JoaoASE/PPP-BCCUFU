public class IPhoneX implements Celular {
    public void fazLigacao(){ System.out.println("iPhone X realizando ligação."); }
    public void tiraFoto(){ System.out.println("iPhone X tirando foto."); }
}