/**
 * Interface comum para todos os veículos.
 */
public interface IVehicle {
    void start();
    void drive();
    void stop();
}