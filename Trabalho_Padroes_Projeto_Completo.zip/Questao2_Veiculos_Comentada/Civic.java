public class Civic implements IVehicle {

    public void start() { System.out.println("Civic ligado."); }
    public void drive() { System.out.println("Civic rodando."); }
    public void stop() { System.out.println("Civic parado."); }
}