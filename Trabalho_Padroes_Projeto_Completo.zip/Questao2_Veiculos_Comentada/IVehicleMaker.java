/**
 * Interface das fábricas de veículos.
 * O método makeVehicle representa o padrão Factory Method.
 */
public interface IVehicleMaker {
    IVehicle makeVehicle(String modelo);
}