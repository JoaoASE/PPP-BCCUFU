public class Main {
    public static void main(String[] args) {
        IVehicleMaker toyota = Toyota.getInstance();
        IVehicleMaker honda = Honda.getInstance();

        IVehicle carro1 = toyota.makeVehicle("Corolla");
        IVehicle carro2 = honda.makeVehicle("Civic");

        carro1.start();
        carro1.drive();
        carro1.stop();

        carro2.start();
        carro2.drive();
        carro2.stop();
    }
}