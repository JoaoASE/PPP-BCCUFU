public class Honda implements IVehicleMaker {
    private static Honda instancia;
    private Honda(){}
    public static Honda getInstance(){
        if(instancia == null) instancia = new Honda();
        return instancia;
    }
    public IVehicle makeVehicle(String modelo){
        if(modelo.equalsIgnoreCase("Civic")) return new Civic();
        if(modelo.equalsIgnoreCase("City")) return new City();
        if(modelo.equalsIgnoreCase("Fit")) return new Fit();
        return null;
    }
}