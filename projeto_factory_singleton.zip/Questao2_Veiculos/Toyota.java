public class Toyota implements IVehicleMaker {
    private static Toyota instancia;
    private Toyota(){}
    public static Toyota getInstance(){
        if(instancia == null) instancia = new Toyota();
        return instancia;
    }
    public IVehicle makeVehicle(String modelo){
        if(modelo.equalsIgnoreCase("Corolla")) return new Corolla();
        if(modelo.equalsIgnoreCase("Hilux")) return new Hilux();
        if(modelo.equalsIgnoreCase("Etios")) return new Etios();
        return null;
    }
}